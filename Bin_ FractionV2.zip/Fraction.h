
class Fraction {

  public:
    ///Constructors
    Fraction();
    Fraction(int n, int d);

    ///Destructor
    ~Fraction();
    //input information for fraction
    void setNumerator(int n);
    void setDenominator(int d);
    //return information from fraction
    int getNumerator() const {
        return numerator;
    };
    int getDenominator() const {
        return denominator;
    };
    //convert fraction to string
    string toString();
    //convert fraction to decimal
    double toDouble();
    //convert fraction to reciprocal
    void reciprocal();
    //checks fraction equalities
    bool equals(Fraction f);
    //multiply itself
    void multiply(Fraction f);
    //divide itself
    void divide(Fraction f);
    //add itself
    void add(Fraction f);
    //subtract itself
    void subtract(Fraction f);

    ///Static Methods:
    static Fraction add(Fraction f1, Fraction f2);
    static Fraction subtract(Fraction f1, Fraction f2);
    static Fraction multiply(Fraction f1, Fraction f2);
    static Fraction divide(Fraction f1, Fraction f2);
    static Fraction reciprocal(Fraction f1);

  private:
    int numerator;
    int denominator;
    void reduce();
};

