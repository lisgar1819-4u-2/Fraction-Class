/***************************************************

Bin (Quoc Dat Phung)
Teacher: Ms. Lindsay Cullum
Date: April 1, 2019

        Program that uses CLASSES to print
        or make calculations with fractions.


***************************************************/


#include <iostream>
using namespace std;
#include <iomanip>
#include "ctype.h"
#include "Fraction.h"

//prototypes:
void fixed_Decimal_Place();
void logicError(Fraction f1, Fraction f2);
void printOperations(Fraction f1, Fraction f2);
void printReciprocal(Fraction f1, Fraction f2);
void makeSure(Fraction f1, Fraction f2);
void checkEquality(Fraction f1, Fraction f2);



int main () {

//show only 3 decimal points
    fixed_Decimal_Place();


//OBJECTS:
    Fraction f1(1, 5);
    Fraction f2(3, 5);

    cout << "Test One --------------------------------------------------------------\n" << endl;
    cout << "Are there any logic errors in your Fraction class?"<< endl;
    cout << "Let's begin with the fractions:" << endl;

    logicError(f1, f2);      // prints out f1 and f2 into decimals
    printOperations(f1, f2); // addition, subtraction, multiplication, division.
    printReciprocal(f1, f2); // print out the reciprocal of f1 and f2.
    makeSure(f1, f2);        //make sure the initial values of f1 and f2 are not changed.

    cout << "Test Two --------------------------------------------------------------\n" << endl;

    cout << "Let's change f1 so that it is now its reciprocal" << endl;
    cout << "and let's change the numerator of f2 to 13 and try our calculations again:\n";

    f1.reciprocal();
    f2.setNumerator(13);

    cout << "The two original fractions are now: \n" << endl;
    logicError(f1, f2);      // prints out f1 and f2 into decimals
    printOperations(f1, f2); // addition, subtraction, multiplication, division.
    printReciprocal(f1, f2); // print out the reciprocal of f1 and f2.
    makeSure(f1, f2);        //make sure the initial values of f1 and f2 are not changed.

    cout << "Test Three --------------------------------------------------------------\n" << endl;
    f1.setNumerator(3);
    f1.setDenominator(8);
    f2.setNumerator(1);
    f2.setDenominator(4);

    logicError(f1, f2);      // prints out f1 and f2 into decimals
    printOperations(f1, f2); // addition, subtraction, multiplication, division.
    makeSure(f1, f2);        //make sure the initial values of f1 and f2 are not changed.

    cout << "Test Four --------------------------------------------------------------\n" << endl;
    f1.reciprocal();
    f2.setNumerator(13);

    logicError(f1, f2);      // prints out f1 and f2 into decimals
    printOperations(f1, f2); // addition, subtraction, multiplication, division.
    makeSure(f1, f2);        //make sure the initial values of f1 and f2 are not changed.

    cout << "Test Five --------------------------------------------------------------\n" << endl;
    cout << "I suppose we should also check for fraction equality: ";
    checkEquality(f1, f2);

    cout << "\nFinished --------------------------------------------------------------\n" << endl;
    return 0;
}
void fixed_Decimal_Place() {
    cout << setprecision(3);
    cout.setf(ios::showpoint | ios::fixed);
    cout.setf(ios::right, ios::adjustfield);
}

void logicError(Fraction f1, Fraction f2) {
    cout << "f1 = " + f1.toString() + " or " << f1.toDouble() << endl;
    cout << "f2 = " + f2.toString() + " or " << f2.toDouble() << "\n"<< endl;
}

void printOperations(Fraction f1, Fraction f2) {
    cout << f1.toString() + " + " + f2.toString() + " = " + Fraction::add(f1, f2).toString() << endl;
    cout << f1.toString() + " - " + f2.toString() + " = " + Fraction::subtract(f1, f2).toString() << endl;
    cout << f1.toString() + " x " + f2.toString() + " = " + Fraction::multiply(f1, f2).toString() << endl;
    cout << f1.toString() + " / " + f2.toString() + " = " + Fraction::divide(f1, f2).toString() << endl;
}

void printReciprocal(Fraction f1, Fraction f2) {
    cout << endl;
    cout << "   Reciprocal of f1 = " + Fraction::reciprocal(f1).toString() << endl;
    cout << "   Reciprocal of f2 = " + Fraction::reciprocal(f2).toString() << endl;
}

void makeSure(Fraction f1, Fraction f2) {
    cout << endl;
    cout << "   Let's make sure that the original fractions have not been changed:" << endl;
    cout << "   f1 = " + f1.toString() + " or " << f1.toDouble() << endl;
    cout << "   f2 = " + f2.toString() + " or " << f2.toDouble() << "\n"<< endl;
}

void checkEquality(Fraction f1, Fraction f2) {
    if(f1.equals(f2))
        cout << "The fractions are equal." << endl;
    else
        cout << "The fractions are not equal" << endl;
}
