#include <iostream>
using namespace std;

#include "Fraction.h"
#include <cmath>


///Constructor
Fraction::Fraction() {
    numerator = 0;
    denominator = 0;
}

Fraction::Fraction(int n, int d) {
    numerator = n;
    denominator = d;
}

///Destructor
Fraction::~Fraction() {
//cout << "Deleting constructor..." << endl;
}

///Methods:
void Fraction::setNumerator(int n) {
//input n becomes numerator
    numerator = n;
}

void Fraction::setDenominator(int d) {
//d becomes denominator
    denominator = d;
}

string Fraction::toString() {
//Convert fraction into a string
    string n;   //string numerator
    string d;   //string denominator
    string s;   //our final string

//convert from int to string
    n = to_string(numerator);
    d = to_string(denominator);

    s = n + "/" + d;
    return s;
}

double Fraction::toDouble() {
//convert fraction to decimal
    return (double(numerator)/double(denominator));
}

void Fraction::reciprocal() {
    int num, de;
    num = numerator;
    de = denominator;
    //change it back...
    numerator = de;
    denominator = num;
}

bool Fraction::equals(Fraction f) {
    if (numerator == f.getNumerator() &&
            denominator == f.getDenominator()) {
        return true;

    } else {
        return false;
    }
}

void Fraction::multiply(Fraction f) {
    //fraction power of 2

    f.setNumerator(f.getNumerator()*
                   f.getNumerator());
    f.setDenominator(f.getDenominator()*
                     f.getDenominator());
    f.reduce();
}

void Fraction::divide(Fraction f) {
    //fraction divides itself
    //a/b / b/a = a/b x b/a = 1;
    f.setNumerator(f.getNumerator()*
                   f.getDenominator());
    f.setDenominator(f.getDenominator()*
                     f.getNumerator());
}

void Fraction::add(Fraction f) {
//add itself
// a/b + a/b = (a+a)/b
    f.setNumerator(f.getNumerator()+
                   f.getNumerator());
    f.setDenominator(f.getDenominator());
}

void Fraction::subtract(Fraction f) {
//add itself
// a/b - a/b = (a-a)/b = 0
    f.setNumerator(f.getNumerator()-
                   f.getNumerator());
    f.setDenominator(f.getDenominator());
}

void Fraction::reduce() {
    int gcf = 1; //later num divide this
//so this better be greater than 0;
    /*finding greatest common factor
    simplyfying fraction means the...
    numerator and denominator must...
    divide that gcf */

//does not make sense for i to be 0 or 1
//does not make sense that 0 or 1 should
//be divisible because it doesn't do anything.
    for(int i=2; i<=numerator && i<=denominator; i++) {
        //if they share a common factor
        if (numerator%i==0 && denominator%i==0) {
            gcf=i;
            break;
        }
    }
    numerator = numerator / gcf;
    denominator = denominator /gcf;
}

Fraction Fraction::add(Fraction f1, Fraction f2) {
//addition: a/b + c/d = (ad + bc)/bd
//formula applies below;

    int ad, bc, bd;
    ad = f1.getNumerator()*f2.getDenominator();
    bc = f2.getNumerator()*f1.getDenominator();
    bd = f1.getDenominator()*f2.getDenominator();

    Fraction f3(0,0);

//if adding negative fractions... and
//if negative fraction's magnitude > other one
    if (bc < 0 && bc*(-1) > ad) {
        f3.setNumerator(bc*-1 - ad);
        f3.setDenominator(bd);
        f3.reduce();    //simplifying fraction with method.
        f3.reduce();    //simplifying fraction with method.
        f3.setNumerator(f3.getNumerator()*-1);
    } else {
        f3.setNumerator(ad + bc);
        f3.setDenominator(bd);
        f3.reduce();    //simplifying fraction with method.
        f3.reduce();    //simplifying fraction with method.
    }
    return f3;
}


Fraction Fraction::subtract(Fraction f1, Fraction f2) {
    /*
    a/b - c/d = (ad - cb)/bd
    if numerator is negative then it causes trouble.
    Thus, make it cb - ad over bd and then multiply
    the whole thing by -1 later.
    */
    int ad, cb, bd;
    ad = f1.getNumerator()*f2.getDenominator();
    cb = f2.getNumerator()*f1.getDenominator();
    bd = f1.getDenominator()*f2.getDenominator();

    Fraction f3(0,0);
    if ((ad - cb) < 0 ) {
        f3.setNumerator(cb - ad);
        f3.setDenominator(bd);
        f3.reduce();
        f3.reduce();
        //make fraction negative
        f3.setNumerator(f3.getNumerator()*-1);
    } else {
        f3.setNumerator(ad - cb);
        f3.setDenominator(bd);
        f3.reduce();
        f3.reduce();
    }
    return f3;
}


Fraction Fraction::multiply(Fraction f1, Fraction f2) {
//addition: a/b * c/d = ac/bd
//formula applies below;
    int ac, bd;
    ac = f1.getNumerator()*f2.getNumerator();
    bd = f1.getDenominator()*f2.getDenominator();

    Fraction f3(0,0);

    f3.setNumerator(ac);
    f3.setDenominator(bd);
    f3.reduce();    //simplifying fraction with method.
    f3.reduce();
    return f3;
}

Fraction Fraction::divide(Fraction f1, Fraction f2) {
//addition: a/b / c/d = ad/bc
//formula applies below;
    int ad, bc;
    ad = f1.getNumerator()*f2.getDenominator();
    bc = f1.getDenominator()*f2.getNumerator();

    Fraction f3(0,0);
    f3.setNumerator(ad);
    f3.setDenominator(bc);
    f3.reduce();    //simplifying fraction with method.
    f3.reduce();
    return f3;
}


Fraction Fraction::reciprocal(Fraction f1) {
//reciprocal: a/b = b/a
    int num, de;

    num = f1.getNumerator();
    de = f1.getDenominator();

    f1.setNumerator(de);
    f1.setDenominator(num);
    f1.reduce();    //simplifying fraction with method.
    return f1;
}
